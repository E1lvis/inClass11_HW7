package edu.uncc.inclass11;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

import edu.uncc.inclass11.databinding.FragmentGradesBinding;
import edu.uncc.inclass11.databinding.GradeRowItemBinding;



public class GradesFragment extends Fragment {
    ArrayList<Grade> grades = new ArrayList<>();
    public GradesFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
    }

    FragmentGradesBinding binding;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentGradesBinding.inflate(inflater, container, false);

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);






        ImageButton button = view.findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.createCourse();
            }
        });



        getData();
        recycler = view.findViewById(R.id.recycler);
        getActivity().setTitle("Grades");
        Log.d("TAG", "GRADES LIST SIZE:" + grades.size());



    }
    gradeAdapter gradeAdapter;
    RecyclerView recycler;
    class gradeAdapter extends RecyclerView.Adapter<gradeAdapter.gradesViewHolder>{
        ArrayList<Grade> mGrades = new ArrayList<>();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        public gradeAdapter(ArrayList<Grade> mGrades) {
            this.mGrades = mGrades;
        }

        @NonNull
        @Override
        public gradesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            GradeRowItemBinding binding = GradeRowItemBinding.inflate(getLayoutInflater(), parent, false);
            return new gradesViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull gradesViewHolder holder, int position) {
            Grade grade = mGrades.get(position);
            holder.setupUI(grade);
        }

        @Override
        public int getItemCount() {
            return mGrades.size();
        }

        public class gradesViewHolder extends RecyclerView.ViewHolder {
            Grade mGrade;
            GradeRowItemBinding mBinding;
            public gradesViewHolder(@NonNull GradeRowItemBinding itemView) {
                super(itemView.getRoot());
                mBinding = itemView;

            }

            public void setupUI(Grade grade){


                mGrade = grade;
                mBinding.textViewCourseHours.setText(grade.getCourse_hours().toString());
                mBinding.textViewCourseLetterGrade.setText(grade.getCourse_grade());
                mBinding.textViewCourseName.setText(grade.getCourse_name());
                mBinding.textViewCourseNumber.setText(grade.getCourse_number());

                //set up visibility of grades based on UID, the post have a UID connected to them already
                if (grade.getCreated_by_uid().equals(user.getUid())){
                    mBinding.imageViewDelete.setVisibility(View.VISIBLE);
                    mBinding.textViewCourseLetterGrade.setVisibility(View.VISIBLE);
                } else {
                    mBinding.imageViewDelete.setVisibility(View.INVISIBLE);
                    mBinding.textViewCourseLetterGrade.setVisibility(View.INVISIBLE);
                }

                mBinding.imageViewDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (grade.getCreated_by_uid().equals(user.getUid())){

                            FirebaseFirestore db = FirebaseFirestore.getInstance();

                            db.collection("Grades").document(grade.getCreated_by_uid()).delete();
                            grades.remove(grade);
                            notifyDataSetChanged();
                        }
                    }
                });

            }


        }
    }

    private void getData(){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("grades")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        grades.clear();
                        for(QueryDocumentSnapshot gradeRecieved : value){
                            Grade grade = gradeRecieved.toObject(Grade.class);

                            grades.add(grade);
                            Log.d("TAG", "onEvent: " + grades.size());
                        }
                        double test = calculateGPA();

                        gradeAdapter = new gradeAdapter(grades);
                        recycler.setAdapter(gradeAdapter);
                        recycler.setLayoutManager(new LinearLayoutManager(getContext()));
                    }
                });
    }

    GradesListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (GradesFragment.GradesListener) context;
    }

    interface GradesListener {

        void createCourse();
    }

    public double calculateGPA() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        double grade = 0.0;
        int gradePoints = 0;
        int credits = 0;
        for(Grade g : grades){
            if (g.getCreated_by_uid().equals(user.getUid())){
                credits += g.getCourse_hours();
                Log.d("TAG", "calculateGPA: " + g.getCourse_grade());
                if(g.getCourse_grade().equals("A")){
                    gradePoints += g.getCourse_hours() * 4;
                }else if(g.getCourse_grade().equals("B")){
                    gradePoints += g.getCourse_hours() * 3;
                }else if(g.getCourse_grade().equals("C")){
                    gradePoints += g.getCourse_hours() * 2;
                }else if(g.getCourse_grade().equals("D")){
                    gradePoints += g.getCourse_hours() * 1;
                }else if(g.getCourse_grade().equals("F")){
                    gradePoints += g.getCourse_hours() * 0;
                }
            }
            }


        if (credits == 0){
            credits = 1;
        }
        Log.d("TAG", "calculateGPA: " + gradePoints + " " + credits);
        grade = gradePoints/credits;
        binding.textViewGPA.setText("GPA: " + String.valueOf(grade));
        return grade;

    }
}