package edu.uncc.inclass11;

public class Grade {
     public String course_name, course_number,  course_grade, created_by_uid, id;
     public double course_hours;




    public String getCourse_name() {
        return course_name;
    }

    public void setCourse_name(String course_name) {
        this.course_name = course_name;
    }

    public String getCourse_number() {
        return course_number;
    }

    public void setCourse_number(String course_number) {
        this.course_number = course_number;
    }

    public Double getCourse_hours() {
        return course_hours;
    }

    public void setCourse_hours(Double course_hours) {
        this.course_hours = course_hours;
    }

    public String getCourse_grade() {
        return course_grade;
    }

    public void setCourse_grade(String course_grade) {
        this.course_grade = course_grade;
    }

    public String getCreated_by_uid() {
        return created_by_uid;
    }

    public void setCreated_by_uid(String created_by_uid) {
        this.created_by_uid = created_by_uid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Grade{" +
                "course_name='" + course_name + '\'' +
                ", course_number='" + course_number + '\'' +
                ", course_hours='" + course_hours + '\'' +
                ", course_grade='" + course_grade + '\'' +
                ", created_by_uid='" + created_by_uid + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}
